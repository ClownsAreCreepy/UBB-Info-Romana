import unittest

from domain.player import Player
from repository.repository import PlayersRepositoryMemory, PlayersRepositoryFile


class TestRepository(unittest.TestCase):
    def setUp(self) -> None:
        print("setUp called")
        self.test_repo = PlayersRepositoryMemory()

    def test_store(self):
        print("test_store")
        self.assertEqual(len(self.test_repo.all), 0)
        p = Player("Test Player", "Country", 1286, 1100, 3522)
        self.test_repo.store(p)
        self.assertEqual(len(self.test_repo.all), 1)

    def test_get_all(self):
        print("test_get_all")
        self.assertEqual(len(self.test_repo.all), 0)
        p1 = Player("Test Player", "Country", 1286, 1100, 3522)
        self.test_repo.store(p1)
        self.assertEqual(len(self.test_repo.all), 1)
        p2 = Player("Test Player1", "Country2", 1286, 1100, 3522)
        self.test_repo.store(p2)
        self.assertEqual(len(self.test_repo.all), 2)

    def tearDown(self) -> None:
        print("tearDown called")



class TestRepositoryFile(unittest.TestCase):
    def setUp(self):
        self.test_repo = PlayersRepositoryFile("test_players.txt")

    def test_store(self):
        self.assertEqual(len(self.test_repo.all), 1)
        p1 = Player("Test Player", "Country", 1286, 1100, 3522)
        self.test_repo.store(p1)
        self.assertEqual(len(self.test_repo.all), 2)

    def tearDown(self):
        pass