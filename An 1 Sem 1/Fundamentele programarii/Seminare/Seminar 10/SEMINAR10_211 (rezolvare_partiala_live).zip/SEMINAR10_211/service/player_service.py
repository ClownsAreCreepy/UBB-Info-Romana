from domain.player import Player


class PlayerService:
    def __init__(self, repo, validator):
        self.__repo = repo
        self.__validator = validator

    def add(self, name, country, matches_played, matches_won, points):
        p = Player(name, country, matches_played, matches_won, points)
        #self.__validator.validate(p)
        self.__repo.store(p)
