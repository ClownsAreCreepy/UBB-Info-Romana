# from ui.gui import run
from list_manager.list_manager import ruleaza_teste
from ui.console import run


run()
