class ValidatorPlayer:
    pass