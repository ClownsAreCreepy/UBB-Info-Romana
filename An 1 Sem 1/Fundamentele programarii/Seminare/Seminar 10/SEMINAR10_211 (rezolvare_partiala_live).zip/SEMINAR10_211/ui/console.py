from colorama import Fore


class Console:
    def __init__(self, srv):
        self.__srv = srv

    def print_menu(self):
        print("1. Add player")
        print("2. Exit")

    def run(self):
        while True:
            try:
                self.print_menu()
                option = int(input(">>>"))
                match option:
                    case 1:
                        self.__add_player_ui()
                    case 2:
                        break
            except Exception as e:
                print(str(e))

    def __add_player_ui(self):
        name = input("Name:")
        country = input("Country:")
        matches_played = int(input("Matches played:"))
        matches_won = int(input("Matches won:"))
        points = int(input("Points:"))
        self.__srv.add(name, country, matches_played, matches_won, points)


