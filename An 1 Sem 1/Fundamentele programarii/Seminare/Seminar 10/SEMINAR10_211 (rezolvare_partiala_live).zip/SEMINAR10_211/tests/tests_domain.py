import unittest

from domain.player import Player


class TestDomain(unittest.TestCase):
    def setUp(self) -> None:
        pass

    def test_player(self):
        p = Player("Test Player", "Country", 1286, 1100, 3522)
        self.assertEqual(p.name, "Test Player")
        self.assertEqual(p.country, "Country")
        self.assertEqual(p.matches_played, 1286)
        self.assertEqual(p.matches_won, 1100)
        self.assertEqual(p.points, 3522)


    def tearDown(self) -> None:
        pass


if __name__=="__main__":
    unittest.main()