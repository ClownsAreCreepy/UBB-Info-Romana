from domain.validator import ValidatorPlayer
from repository.repository import PlayersRepositoryFile
from service.player_service import PlayerService
from ui.console import Console

repo = PlayersRepositoryFile("data/players.txt")

validator = ValidatorPlayer()
srv = PlayerService(repo, validator)
console = Console(srv)
console.run()