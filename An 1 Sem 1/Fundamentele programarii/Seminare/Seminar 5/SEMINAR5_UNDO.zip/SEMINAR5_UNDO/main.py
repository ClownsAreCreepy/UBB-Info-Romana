from ui.console import run


run()